﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatabaseFirstExercise
{
    class Program
    {
        static void Main(string[] args)
        {
            var context = new VidzyEntities();
            context.AddVideo("Video 4", DateTime.Today, "Comedy", (byte) Classification.Gold);

        }
    }
}
